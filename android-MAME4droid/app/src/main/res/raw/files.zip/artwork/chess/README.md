# **Chesspieces** #

Place chesspieces for use with internal artwork here, each SVG is expected to be square with transparent background. They are used with sensorboard device chesspieces simulation, as well as button labels in some cases.

The ones that are included in MAME by default are licensed under the [BSD-3-Clause](http://opensource.org/licenses/BSD-3-Clause). Copyright Colin M.L. Burnett, with contributions from other Wikipedia users. Revision 28 July 2022.